# BHB Tool Lite

**Created by Ojocoder | BHB Brand**

BHB Tool Lite ni zana rahisi ya kutumia kwenye terminal ambayo inakusaidia kufanya yafuatayo:
- [1] Port Scanner
- [2] IP Info Checker
- [3] Website Header Grabber

## Mahitaji

- Termux (kwa simu)
- curl
- nmap
- jq

Install kwa Termux:
```bash
pkg install curl nmap jq
```

## Jinsi ya kutumia

```bash
bash bhb-tool-lite.sh
```

## Mchoro wa Mwanzo

```text
██████╗ ██╗  ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗
██╔══██╗██║  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔════╝ ██║
██████╔╝███████║██████╔╝       ██║   ██║   ██║██║  ███╗██║
██╔═══╝ ██╔══██║██╔═══╝        ██║   ██║   ██║██║   ██║██║
██║     ██║  ██║██║            ██║   ╚██████╔╝╚██████╔╝███████╗
╚═╝     ╚═╝  ╚═╝╚═╝            ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
```
