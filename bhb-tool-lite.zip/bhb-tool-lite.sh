#!/bin/bash

clear
echo "                                          ██████╗ ██╗  ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗"
echo "                                          ██╔══██╗██║  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔════╝ ██║"
echo "                                          ██████╔╝███████║██████╔╝       ██║   ██║   ██║██║  ███╗██║"
echo "                                          ██╔═══╝ ██╔══██║██╔═══╝        ██║   ██║   ██║██║   ██║██║"
echo "                                          ██║     ██║  ██║██║            ██║   ╚██████╔╝╚██████╔╝███████╗"
echo "                                          ╚═╝     ╚═╝  ╚═╝╚═╝            ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝"
echo "                                         Created by Ojocoder | BHB Tool Lite"
echo ""
echo "[1] Port Scanner"
echo "[2] IP Info Checker"
echo "[3] Website Header Grabber"
echo "[0] Exit"
echo ""
read -p "Chagua option: " option

if [ "$option" == "1" ]; then
    read -p "Weka IP address au domain: " ip
    nmap -Pn "$ip"

elif [ "$option" == "2" ]; then
    read -p "Weka IP address: " ip
    curl -s "http://ip-api.com/json/$ip" | jq

elif [ "$option" == "3" ]; then
    read -p "Weka website URL (mfano: https://example.com): " url
    curl -I "$url"

elif [ "$option" == "0" ]; then
    echo "Asante kwa kutumia BHB Tool Lite!"
    exit 0

else
    echo "Chaguo batili."
fi
